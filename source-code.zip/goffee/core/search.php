<div id="search_box">
  <div class="search-container">
    <form action="" method="post">
      <input type="text" placeholder="Αναζήτηση.." name="searchText">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
</div>
