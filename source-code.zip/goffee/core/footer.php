<!-- Footer bar -->
<div id="footer_outter">
	<div id="footer_inner">
		<footer>All rights reserved. Developed by ME<br>vtzivaras@gmail.com</footer>
	</div>
</div>