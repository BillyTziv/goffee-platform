<?php
	// Database settings - change them with your own settings
	$servername = "localhost";
	$username = "sk336835_ordertsuser";
	$password = "U9vS8tuh";
	$dbname = "sk336835_orderts";

	// Trying to connect to the database
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	if( !$conn ) {
		die("Database connection failed: " . mysqli_connect_error());
	}else{
		$conn->set_charset("utf8");
	}
?>
