<?php
	// Database settings - change them with your own settings
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "taskmanager";

	// Trying to connect to the database
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	if( !$conn ) {
		die("Database connection failed: " . mysqli_connect_error());
	}else{
		$conn->set_charset("utf8");
	}
?>
