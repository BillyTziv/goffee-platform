<div id="filter_list">
  <form action="" method="POST">
    <ul>
      <li>
        <select name="orderDate">
          <option value="today">Τρέχουσας ημέρας</option>
          <option value="last3days">Τελευταίες 3 μέρες</option>
          <option value="all">Όλες</option>
        </select>
      </li>
      <li>
        <select name="orderStatus">
          <option value="open">Ανοιχτές</option>
          <option value="working">Σε εξέλιξη</option>
          <option value="completed">Ολοκληρωμένες</option>
          <option value="all">Όλες</option>
        </select>
      </li>
      <li>
        <input type="submit" value="Ανανέωση">
      </li>
    </ol>
  </form>
</div>
